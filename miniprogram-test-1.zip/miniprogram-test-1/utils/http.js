function request(url,callback){
  wx.request({
    url:url,
    success:function(res){
      callback(res.data);
    }
  })
}
function getHttp(url,title,key,callback){
  wx.request({
    url: url,
    success: function (res) {
      callback(res.data,title,key);
    }
  })
}
module.exports = {
  request,
  getHttp
}