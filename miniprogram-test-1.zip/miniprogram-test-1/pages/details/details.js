let app = getApp();
let http = require('../../utils/http.js');
Page({
  data: {
    mvDetail: {},
    title:""
  },
  onLoad(options) {
    let api = app.globalData.movies;
    let id = options.id;
    
    http.request(api.url + api.subject + '/' + id, this.getDetails);
    console.log(this.data.mvDetail)
  },
  getDetails(res) {
    this.setData({
      mvDetail: res,
      title: res.title
    })
    
    

    setTimeout(function () {
      wx.hideLoading()
    }, 1000)
    wx.setNavigationBarTitle({
      title: res.title
    })
  }
})