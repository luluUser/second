
let app = getApp();
let http = require("../../utils/http")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    moreMovies:[],
    start:0,
    count:15,
    httpStr:"",
    title:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let title = options.title;
    console.log(title)
    let str = app.globalData.movies;
    let httpStr = "";
    switch(title){
      case "影院热映": httpStr = str.url + str.coming_soon; break;
      case "豆瓣热门": httpStr = str.url + str.in_theaters; break;
      case "top250": httpStr = str.url + str.top250; 
    }
    this.setData({
      httpStr:httpStr,
      title:title
    });
    wx.showLoading({
      title: 'loading......',
    })
    http.request(httpStr, this.getMore)
    setTimeout(function () {
      wx.hideLoading()
    }, 1000)
  },
  getMore(res){
    let tmpMore = [];
    if(this.data.start > 0){
      tmpMore = this.data.moreMovies.concat(res.subjects)
    }else{
      tmpMore = res.subjects
    }
    this.data.start += this.data.count
    this.setData({
      moreMovies:tmpMore
    })
    console.log(this.data.moreMovies)
  },
  loadBottom(){
    let url = this.data.httpStr + "?start=" + this.data.start + "&count=" + this.data.count;
    wx.showLoading({
      title: '请稍侯...',
    })
    http.request(url,this.getMore);
    setTimeout(function () {
      wx.hideLoading()
    }, 1000)
  },
  toDetails(e){
    let id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url:"/pages/details/details?id=" +id
    })
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})