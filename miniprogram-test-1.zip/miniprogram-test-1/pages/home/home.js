let app = getApp();
let http = require("../../utils/http.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    movies:{
      coming_soon:"",
      in_theaters:"",
      top250:""
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(app.globalData.movies);
    let str = app.globalData.movies;
    /*wx.request({
      url: str.url + str.coming_soon,
      success(res) {
        console.log(res);
        //console.log(that);
        that.setData({
          movies: res.data.subjects
        })
      }
    }),*/
    //http.request(str.url + str.coming_soon, this.getComing)
    http.getHttp(str.url + str.coming_soon, "影院热映", "coming_soon", this.getMovies)
    http.getHttp(str.url + str.in_theaters, "豆瓣热门", "in_theaters", this.getMovies)
    http.getHttp(str.url + str.top250, "top250", "top250", this.getMovies);
  },
  //getComing(res) {
    //console.log(res.subjects)
  //},
  getMovies(res, title, key) {
    this.data.movies[key] = {
      title: title,
      list: res.subjects 
    }
    this.setData({
      movies: this.data.movies
    })
  },
  toDetails(e){
    let id = e.currentTarget.dataset.id
    wx.navigateTo({
      url:"/pages/details/details?id=" + id
    })
  },
  toMore(e){
   let title = e.currentTarget.dataset.title;
   wx.navigateTo({
     url: "/pages/more/more?title=" + title,
   })
  },
  toSearch() {
    wx.navigateTo({
      url: "/pages/search/search"
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})