// pages/classifyProduct/classifyProduct.js
import { getCategoryProduct, showLoading, cancelLoading } from '../../utils/request.js'
let typeId = '';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    tinyNavIsShow: false,
    selectedIsok: true,//筛选条件
    brandSelectedIsok: '',//品牌点击动态添加
    brandHideShow: true,//品牌列表动态展示
    selectedList: [
      { dataType: 1, dataOrder: 'id', dataSorter: 'desc', content: '综合排序' },
      { dataType: 2, dataOrder: 'num', dataSorter: 'desc', content: '销量最多' },
      { dataType: 3, dataOrder: 'price', dataSorter: 'desc', content: '价格从高到低' },
      { dataType: 3, dataOrder: 'price', dataSorter: 'asc', content: '价格从低到高' },
      ],
    defaultSelected: { dataType: 1, dataOrder: 'id', dataSorter: 'desc', content: '综合排序' },
    brandList: [],
    brandId: '',
    brandSureID: '',
    productList:[],//商品列表数据
    pages: 1,
    canloadMore: true,
    scrollTop: 0
  
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options)
    typeId = options.id;
    let typeName = options.name;
    wx.setNavigationBarTitle({ title: typeName })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.getIniData();
  },
  getIniData() {
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    let bindID = this.data.brandId;
    showLoading();
    // console.log(typeId, page, defSelected)
    getCategoryProduct(typeId, page, defSelected.dataOrder, defSelected.dataSorter, defSelected.dataType, bindID).then((result) => {
        this.setData({
          productList: result.data.products,
          brandList: result.data.brands
        });
        cancelLoading();
    });
  },
  // 呼吸导航
  tinyNavHideShow: function () {
    this.setData({
      tinyNavIsShow: false
    });
  },
  // 呼吸导航。。。
  tinyNavHideShowprot: function () {
    this.setData({
      tinyNavIsShow: true
    });
  },
  // 跳转至搜索页面
  goToIndex: function () {
    wx.switchTab({
      url: "../index/index",
    })
  },
  // 跳转至搜索页面
  goToSearch: function () {
    wx.navigateTo({
      url: "../search/search",
    })
  },
  // 跳转至品牌商品页面
  goTobrandProducts: function (event) {
    let { brandid } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../brandProducts/brandProducts?brandId=${brandid}`,
    })
  },
  bindNone: function () { },
  // 跳转至商品详情
  goToProductDetail: function (event) {
    let { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../productDetail/productDetail?id=${id}`,
    })
  },
  // brand显示与隐藏
  branHideShow: function () {
    this.setData({
      brandHideShow: true
    });
  },
  brandShow: function () {
    this.setData({
      brandHideShow: false
    });
  },
  // 点击品牌-取消---隐藏
  cancelBtn: function () {
    this.setData({
      brandHideShow: true
    });
  },
  // 点击品牌-确认---隐藏与商品数据渲染
  sureBtn: function () {
    this.setData({
      brandHideShow: true,
      pages: 1,
      canloadMore: true,
      scrollTop: 0, //回到顶部
      brandId: this.data.brandSureID
    });
    this.getIniData();
  },
  // 点击全部品牌
  allBrand: function () {
    this.setData({
      brandHideShow: true,
      pages: 1,
      canloadMore: true,
      scrollTop: 0, //回到顶部
      brandId: '',
      brandSelectedIsok: ''
    });
    this.getIniData();
  },

  // 条件显示与隐藏
  hidShow: function () {
    if (this.data.selectedIsok) {
      this.setData({
        selectedIsok: false
      });
    } else {
      this.setData({
        selectedIsok: true
      });
    }
  },
  // 品牌商品点击
  toggleBrand: function (ev) {
    let { index, id } = ev.currentTarget.dataset;
    this.setData({
      brandSelectedIsok: index,
      brandSureID: id
    });
  },
  // 商品条件筛选
  selectedItems: function (event) {
    let { typed, order, sorter, content } = event.currentTarget.dataset;
    console.log(typed, order, sorter, content);
    this.setData({
      selectedIsok: true,
      pages: 1,
      canloadMore: true,
      scrollTop: 0, //回到顶部
      defaultSelected: { dataType: typed, dataOrder: order, dataSorter: sorter, content }
    });
    this.getIniData();
  },
// scroll-view滚动到底部,加载更多
  lower: function (e) {
    if (!this.data.canloadMore) {
      return;
    }
    this.setData({
      pages: this.data.pages + 1
    })
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    let bindID = this.data.brandId;
    console.log(typeId, page, defSelected)
    getCategoryProduct(typeId, page, defSelected.dataOrder, defSelected.dataSorter, defSelected.dataType, bindID).then((result) => {
      let tmp = this.data.productList.concat(result.data.products);
      if (result.data.productSize < 10) {
        this.setData({
          canloadMore: false,
          productList: tmp
        });
      } else {
        this.setData({
          productList: tmp
        });
      }
    });
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})