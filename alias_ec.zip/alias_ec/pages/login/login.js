// pages/login/login.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    phoneReg: false,
    timer: '',//定时器名字
    countDownNum: '60',//倒计时初始值
    isOkCount: false, //是否开启倒计时
    userCode: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },
  // 获取输入值
  phoneInput: function (ev) {
    let val = ev.detail.value;
    console.log(val)
    let isMobile = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    if (isMobile.test(val)) {
      this.setData({
        phone: val,
        phoneReg: true,
      });
    } else {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
      this.setData({
        phoneReg: false,
      });
    }
    console.log(isMobile.test(val))
  },

  // 点击开启倒计时
  getCode:function(){
    let phone = this.data.phone;
    let phoneReg = this.data.phoneReg;
    if (!phone) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phoneReg) {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
    } else {
      wx.request({
        url: app.globalreq + 'user/checkPhone',
        data: {
          'phone': phone
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res.data)
          if (res.data) {
            this.setData({
              isOkCount: true
            })
            this.countDown();
            wx.request({
              url: app.globalreq + 'user/sendMessage',
              data: {'phone': phone},
              method: 'GET',
              dataType: 'json',
              success: (res) => {
                console.log(res)
              },
              fail: function (res) { },
              complete: function (res) { },
            })

          } else {
            wx.showToast({
              title: '该号码尚未注册',
              icon: 'none',
              duration: 1500
            })
          }

        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }

  },
  countDown: function () {
    let that = this;
    let countDownNum = that.data.countDownNum;//获取倒计时初始值
    //如果将定时器设置在外面，那么用户就看不到countDownNum的数值动态变化，所以要把定时器存进data里面
    that.setData({
      timer: setInterval(function () {//这里把setInterval赋值给变量名为timer的变量
        //每隔一秒countDownNum就减一，实现同步
        countDownNum--;
        //然后把countDownNum存进data，好让用户知道时间在倒计着
        that.setData({
          countDownNum: countDownNum
        })
        //在倒计时还未到0时，这中间可以做其他的事情，按项目需求来
        if (countDownNum <= 0) {
          //这里特别要注意，计时器是始终一直在走的，如果你的时间为0，那么就要关掉定时器！不然相当耗性能
          //因为timer是存在data里面的，所以在关掉时，也要在data里取出后再关闭
          clearInterval(that.data.timer);
          //关闭定时器之后，可作其他处理codes go here
          that.setData({
            isOkCount: false,
            countDownNum: '60'
          })
        }
      }, 1000)
    })
  },

  //获取用户输入验证码
  userCode: function(ev) {
    let val = ev.detail.value;
    this.setData({
      userCode: val
    })
  },
  // 登录
  login: function () {
    let code = this.data.userCode;
    let phone = this.data.phone;
    let phoneReg = this.data.phoneReg;
    if (!code) {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phone) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phoneReg) {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
    } else {
      // 验证码是否正确
      wx.request({
        url: app.globalreq + 'user/validateCode',
        data: {
          'phone': phone,
          'code': code
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res);
          if (res.data) {
            wx.request({
              url: app.globalreq + 'user/doLoginMobile',
              data: { 'userName': phone },
              method: 'GET',
              dataType: 'json',
              success: (res) => {
                console.log(res)
                if (res.data.res) {
                  wx.setStorageSync('baai_user_token', res.data.baai_user_token)
                  wx.switchTab({
                    url: `../index/index`,
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          } else {
            wx.showToast({
              title: '请输入正确的验证码',
              icon: 'none',
              duration: 1500
            })
          }
          
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  },
  // 去首页
  goToIndex: function(){
    wx.switchTab({
      url: `../index/index`,
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})