// pages/loginPassword/loginPassword.js
const app = getApp();
// wx.clearStorageSync()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    phoneReg: false,
    password:'',
    passVerify: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },
  // 获取输入值
  phoneInput: function (ev) {
    let val = ev.detail.value;
    console.log(val)
    let isMobile = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    if ( isMobile.test(val) ) {
      this.setData({
        phone: val,
        phoneReg: true,
      });
    } else {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
      this.setData({
        phoneReg: false,
      });
    }
    console.log(isMobile.test(val))
  },
  passwordInput: function (ev) {
    let val = ev.detail.value;
    console.log(val)
    this.setData({
      password: val
    });
  },
  // 回车值跳转
  onEnterVal: function (ev) {
    console.log(ev.detail.value)
    let val = ev.detail.value;
    let phone = this.data.phone;
    let phoneReg = this.data.phoneReg;
    let password = val;
    if (!phone) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phoneReg) {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
    } else if (!password) {
      wx.showToast({
        title: '请输入登录密码',
        icon: 'none',
        duration: 1500
      })
    } else {

      wx.request({
        url: app.globalreq + 'user/checkPhone',
        data: {
          'phone': phone
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res.data)
          if (res.data) {
            wx.request({
              url: app.globalreq + 'user/doLogin',
              data: {
                'userName': phone,
                'passWord': password
              },
              method: 'GET',
              dataType: 'json',
              success: (res) => {
                console.log(res, res.data.baai_user_token)
                if (res.data.res) {
                  wx.setStorageSync('baai_user_token', res.data.baai_user_token)
                  wx.switchTab({
                    url: `../index/index`,
                  })
                } else {
                  wx.showToast({
                    title: '密码错误',
                    icon: 'none',
                    duration: 1500
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })

          } else {
            wx.showToast({
              title: '该号码尚未注册',
              icon: 'none',
              duration: 1500
            })
          }

        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  },

  // 登录
  login: function() {
    let phone = this.data.phone;
    let phoneReg = this.data.phoneReg;
    let password = this.data.password;
    if ( !phone ) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 1500
      })
    } else if ( !phoneReg ) {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
    } else if (!password) {
      wx.showToast({
        title: '请输入登录密码',
        icon: 'none',
        duration: 1500
      })
    } else {

      wx.request({
        url: app.globalreq + 'user/checkPhone',
        data: {
          'phone': phone
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res.data)
          if (res.data) {
            wx.request({
              url: app.globalreq + 'user/doLogin',
              data: {
                'userName': phone,
                'passWord': password
              },
              method: 'GET',
              dataType: 'json',
              success: (res) => {
                console.log(res, res.data.baai_user_token)
                if (res.data.res) {
                  wx.setStorageSync('baai_user_token', res.data.baai_user_token)
                  wx.switchTab({
                    url: `../index/index`,
                  })
                } else {
                  wx.showToast({
                    title: '密码错误',
                    icon: 'none',
                    duration: 1500
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })

          } else {
            wx.showToast({
              title: '该号码尚未注册',
              icon: 'none',
              duration: 1500
            })
          }

        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }

  },



  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
  //  wx.login({
  //   success: res => {
  //     // ------ 获取凭证 ------
  //     var code = res.code;
  //     console.log(res)
  //     if (code) {
  //       // console.log('获取用户登录凭证：' + code);
  //       // ------ 发送凭证 ------
  //       wx.request({
  //         url: '后台通过获取前端传的code返回openid的接口地址',
  //         data: { code: code },
  //         method: 'POST',
  //         header: {
  //           'content-type': 'application/json'
  //         },
  //         success: function (res) {
  //           if (res.statusCode == 200) {
  //             // console.log("获取到的openid为：" + res.data)
  //             // that.globalData.openid = res.data
  //             wx.setStorageSync('openid', res.data)
  //           } else {
  //             console.log(res.errMsg)
  //           }
  //         },
  //       })
  //     } else {
  //       console.log('获取用户登录失败：' + res.errMsg);
  //     }
  //   }
  // })
})