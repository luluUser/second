// pages/search/search.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    historyIsOk: true, //是否显示搜索历史
    hotList: [{ title: '兰蔻' }, { title: '后' }, { title: '爱丽小屋' }, { title: '兰芝' }, { title: '雪花秀' }, { title: 'AHC' }, { title: '面膜' }, { title: '口红' } ],
    searchValue: '',
  },
  // 回车值跳转
  onEnterVal: function (ev) {
    console.log(ev.detail.value)
    let val = ev.detail.value;
    if (val) {
      wx.navigateTo({
        url: `../searchResult/searchResult?searchVal=${val}`,
      })
    } else {
      wx.showToast({
        title: '请输入搜索内容',
        icon: 'none',
        duration: 2000
      })
    }
  },
  // 获取输入值
  searchInput: function(ev) {
    let val = ev.detail.value;
    console.log(val)
    this.setData({
      searchValue: val
    });
  },
  // 跳转至搜索结果页面
  gotosearchresult: function () {
    let that = this;
    setTimeout(function(){
      let searchV = that.data.searchValue;
      console.log(that.data.searchValue)
      if (searchV) {
        wx.navigateTo({
          url: `../searchResult/searchResult?searchVal=${searchV}`,
        })
      } else {
        wx.showToast({
          title: '请输入搜索内容',
          icon: 'none',
          duration: 2000
        })
      }
    },300)
  },
  hotGoTo: function (event) {
    let { name } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../searchResult/searchResult?searchVal=${name}`,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})