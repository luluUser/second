// pages/add/index.js
// var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    good: {
      goodId: '222333',
      goodImageUrl: '/imgs/goods/mgj2.jpg',
      goodDesc: "商品名称 简要 描述",
      goodPrice: 998,
      goodCount: 1,
      goodChecked:true
    },
    minusImage: '/imgs/icon/minus-bin.png',
    addImage: '/imgs/icon/add.png',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '添加商品',
      success: function (res) {
        // success
      }
    })
  },

  getGoodFromStorage: function () {
    var keys = wx.getStorageInfoSync().keys;
    for (var i in keys) {
      var key = keys[i];
      if (key == this.data.good.goodId){
        var obj = wx.getStorageSync(key);
        this.setData({
          good: obj
        })
        break;
      }
    }
  },

  addOne: function () {
    var newGoodCount = this.data.good.goodCount + 1;
    this.setData({
      'good.goodCount': newGoodCount
    })
    this.checkImageBin();
  },

  minusOne: function () {
    var newGoodCount = this.data.good.goodCount - 1;
    this.setData({
      'good.goodCount': newGoodCount >= 1 ? newGoodCount : 1
    })
    this.checkImageBin();
  },

  checkImageBin:function(){
    var nowGoodCount = this.data.good.goodCount;
    if (nowGoodCount == 1) {
      this.setData({
        minusImage: '/imgs/icon/minus-bin.png'
      })
    } else {
      this.setData({
        minusImage: '/imgs/icon/minus.png'
      })
    }
  },

  bindKeyInput: function (e) {
    this.setData({
      'good.goodCount':  Number(e.detail.value) 
    })
  },

  saveGoodCount: function () {
    wx.setStorage({
      key: this.data.good.goodId,
      data: this.data.good
    })
    wx.navigateTo({
      url: '/pages/detail/index'
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getGoodFromStorage();
    this.checkImageBin();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})