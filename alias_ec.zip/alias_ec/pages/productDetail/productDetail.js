// pages/productDetail/productDetail.js
import { getProductsDetail, getProductsComment, showLoading, cancelLoading } from '../../utils/request.js'
let productId = '';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    productImgs: [],// 轮播
    price: '', //售价
    origPrice: '',//原价
    soldnum: '',//已售
    productName: '',// 商品名称
    hascomment: true, //判断是否有品论
    commentArr: [], //评论
    commentNum: '', //评论总数
    brandName: '',
    brandId: '',
    productIntoImg: '',//商品详情介绍
    showIsShade: false, //蒙版是否显示
    moreShow: true, //底部导航更多,
    isSaved: 0, //是否收藏商品
    soldOut: '', //商品是否下架
    cartShow: false, //购物车是否显示
    buyNowShow: false,
    serverIntro: [
      {itemH: '7天退换', itemB: '商家承诺7天无理由退换货'},
      { itemH: '假一赔十', itemB: '若收到商品是假冒品牌，可获得十倍赔偿' },
      { itemH: '一件代发', itemB: '可一件代发至用户朋友或亲人' },
      { itemH: '素材包服务', itemB: '买家商品可获得精选包装发货' }
      ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    productId = options.id;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 请求数据
    showLoading();
    getProductsDetail(productId).then((result) => {
      if (result.data.status == 400 && result.data.msg == "商品已下架") {
        this.setData({
          soldOut: true
        })
      } else {
        this.setData({
          productImgs: result.data.data.imgs,
          price: result.data.data.showPrice,
          origPrice: result.data.data.origPrice,
          soldnum: result.data.data.num,
          productName: result.data.data.productName,
          brandName: result.data.data.brandName,
          brandId: result.data.data.brandId,
          productIntoImg: result.data.data.description,
          isSaved: result.data.data.isSaved,
          soldOut: false
        });
      }
      cancelLoading();
    });
    getProductsComment(productId).then((result) => {
      // console.log(result)
      if (result.proReviews.length > 0) {
        this.setData({
          hascomment: false,
          commentArr: result.proReviews,
          commentNum: result.reviewCount
        });
      } else {
        this.setData({
          hascomment: true,
          commentNum: result.reviewCount
        });
      }
      
    });
  },
  // 跳转至品牌商品页面
  goTobrandProducts: function (event) {
    let { brandid } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../brandProducts/brandProducts?brandId=${brandid}`,
    })
  },
  // 联系八爱
  callBaai: function () {
    wx.makePhoneCall({
      phoneNumber: '0571-88998830' //八爱客服电话
    })
  },
  // 服务说明显示
  serverIntro: function(){
    this.setData({
      showIsShade: true
    })
  },
  serverIntroHide: function(){
    this.setData({
      showIsShade: false
    })
  },
  // 显示跟多
  moreshow: function(){
    if (this.data.moreShow) {
      this.setData({
        moreShow: false
      })
    } else {
      this.setData({
        moreShow: true
      })
    }
  },
  moreshow02: function () {
    this.setData({
      moreShow: true
    })
  },
  // 分享商品
  showProduct: function(){
    wx.showShareMenu({
      withShareTicket: true,
      success:()=>{
        console.log('转发成功')
      }
    })
  },
  //收藏商品
  collectProduct: function(){
    if (this.data.isSaved) {
      this.setData({
        isSaved: 0
      })
    } else {
      this.setData({
        isSaved: 1
      })
    }
  },
  toAddpage:function(){
    wx.navigateTo({
      url: '/pages/cart/cart',
    })
  },
  // 加入购物车
  joinCart: function(){
    this.setData({
      cartShow: true
    })
  },
  cartShow: function(){
    this.setData({
      cartShow: false
    })
  },
  cartHide: function () {
    this.setData({
      cartShow: false
    })
  },

  // 立即购买
  buyNow: function () {
    this.setData({
      buyNowShow: true
    })
  },
  buyNowShow: function () {
    this.setData({
      buyNowShow: false
    })
  },
  buyNowHide: function () {
    this.setData({
      buyNowShow: false
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    console.log(res)
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: this.data.productName,
      path: '/pages/productDetail/productDetail?id=' + productId
    }
  }
})
