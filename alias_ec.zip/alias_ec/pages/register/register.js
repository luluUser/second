// pages/register/register.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: '',
    phoneReg: false,
    timer: '',//定时器名字
    countDownNum: '60',//倒计时初始值
    isOkCount: false, //是否开启倒计时
    userCode: '',
    loginPass: '',
  
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },
  // 获取输入值
  phoneInput: function (ev) {
    let val = ev.detail.value;
    console.log(val)
    let isMobile = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/;
    if (isMobile.test(val)) {
      this.setData({
        phone: val,
        phoneReg: true,
      });
    } else {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
      this.setData({
        phoneReg: false,
      });
    }
    console.log(isMobile.test(val))
  },
  // 点击开启倒计时
  getCode: function () {
    let phone = this.data.phone;
    let phoneReg = this.data.phoneReg;
    if (!phone) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phoneReg) {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
    } else {
      wx.request({
        url: app.globalreq + 'user/checkPhone',
        data: {
          'phone': phone
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          console.log(res)
          if (!res.data) {
            this.setData({
              isOkCount: true
            })
            this.countDown();
            wx.request({
              url: app.globalreq + 'user/sendMessage',
              data: { 'phone': phone },
              method: 'GET',
              dataType: 'json',
              success: (res) => {
                console.log(res)
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          } else {
            wx.showToast({
              title: '该号码已被注册',
              icon: 'none',
              duration: 1500
            })
          }

        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }

  },
  countDown: function () {
    let that = this;
    let countDownNum = that.data.countDownNum;
    that.setData({
      timer: setInterval(function () {
        countDownNum--;
        that.setData({
          countDownNum: countDownNum
        })
        if (countDownNum <= 0) {
          clearInterval(that.data.timer);
          that.setData({
            isOkCount: false,
            countDownNum: '60'
          })
        }
      }, 1000)
    })
  },
  //获取用户输入验证码
  codeInput: function (ev) {
    let val = ev.detail.value;
    this.setData({
      userCode: val
    })
  },
  passInput: function (ev) {
    let val = ev.detail.value;
    this.setData({
      loginPass: val
    })
  },
  register: function () {
    let code = this.data.userCode;
    let phone = this.data.phone;
    let phoneReg = this.data.phoneReg;
    let loginpass = this.data.loginPass;
    if (!code) {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phone) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 1500
      })
    } else if (!phoneReg) {
      wx.showToast({
        title: '请输入正确的手机格式',
        icon: 'none',
        duration: 1500
      })
    } else if (!loginpass) {
      wx.showToast({
        title: '请设置登录密码',
        icon: 'none',
        duration: 1500
      })
    } else if (loginpass.length < 6) {
      wx.showToast({
        title: '密码不小于6位',
        icon: 'none',
        duration: 1500
      })
    } else {
      // 验证码是否正确
      wx.request({
        url: app.globalreq + 'user/validateCode',
        data: {
          'phone': phone,
          'code': code
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res);
          if (res.data) {
            wx.request({
              url: app.globalreq + 'user/resetPwd',
              data: {
                'phone': phone,
                'password': loginpass,
                'code': code
              },
              method: 'GET',
              dataType: 'json',
              success: (res) => {
                console.log(res)
                if (res.data) {
                  wx.request({
                    url: app.globalreq + 'user/doLogin',
                    data: {
                      'userName': phone,
                      'passWord': loginpass
                    },
                    method: 'GET',
                    dataType: 'json',
                    success: (res) => {
                      console.log(res, res.data.baai_user_token)
                      if (res.data.res) {
                        wx.setStorageSync('baai_user_token', res.data.baai_user_token)
                        wx.switchTab({
                          url: `../index/index`,
                        })
                      } else {
                        wx.showToast({
                          title: '密码错误',
                          icon: 'none',
                          duration: 1500
                        })
                      }
                    },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                } else {
                  wx.showToast({
                    title: '密码修改失败',
                    icon: 'none',
                    duration: 1500
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          } else {
            wx.showToast({
              title: '请输入正确的验证码',
              icon: 'none',
              duration: 1500
            })
          }

        },
        fail: function (res) { },
        complete: function (res) { },
      })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})