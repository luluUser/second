//index.js
//获取应用实例
import { getcategory, getSmallcategory,getIndex, showLoading, cancelLoading } from '../../utils/request.js'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    banners: [],
    faceFilm: [], // 爆款面膜
    washBath: [], // 洗护沐浴
    cosmetics: [], // 魅力彩妆
    mateinfant: [], //母婴保健
    hotFace: [], // 热销面霜
    highCushion: [], //优质气垫
    dailyLife: [], //生活日化
    skinSelect: [], //护肤精选
    bigSign: [], //品质大牌
    femaleBody: [], //身体女性
    delicious: [], //美味零时
    guessLike: [],
    num: 0,
    categoryId: '',
    categoryBig: [],
    categorySmall: [],
    categoryName: '',
  },
 
  // 分类切换
  toggleCategoryList: function (ev) {
    let { index, id, name } = ev.currentTarget.dataset;
    this.setData({
      num: index,
      categoryName: name
    })
    // 小类
    // console.log(id)
    getSmallcategory(id).then((res) => {
      this.setData({
        categorySmall: res
      })
    });
  },
  // 点击小类去分类商品页面
  goToClassifyProduct: function (ev) {
    let { id } = ev.currentTarget.dataset;
    wx.navigateTo({
      url: `../classifyProduct/classifyProduct?id=${id}&name=${this.data.categoryName}`,
    })
  },
  goToSearch : function(){
    wx.navigateTo({
      url: "../search/search",
    })
  },
  navGoTo: function (event) {
    let { titleval } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../searchResult/searchResult?searchVal=${titleval}`,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
  },
  // 跳转至品牌商品页面
  goTobrandProducts: function (event) {
    let { brandid } = event.currentTarget.dataset;
    console.log(brandid)
    wx.navigateTo({
      url: `../brandProducts/brandProducts?brandId=${brandid}`,
    })
  },
  // 跳转至商品详情
  goToProductDetail: function (event) {
    let { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../productDetail/productDetail?id=${id}`,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 请求数据
    showLoading();
    getIndex().then((result)=>{
        this.setData({
          banners: result.IndCarousel,
          faceFilm: result.FaceFilm,
          washBath: result.WashBath,
          cosmetics: result.Cosmetics,
          mateinfant: result.Mateinfant,
          hotFace: result.hotFace,
          highCushion: result.highCushion,
          dailyLife: result.dailyLife,
          skinSelect: result.skinSelect,
          bigSign: result.bigSign,
          femaleBody: result.femaleBody,
          delicious: result.delicious,
          guessLike: result.GuessLike
        });
        cancelLoading();
      });
      getcategory().then(
        (result) => {
          this.setData({
            categoryBig: result,
            categoryId: result[0].id,
            categoryName: result[0].name
          });
          // console.log(this.data.categoryId)
          // 小类
          getSmallcategory(this.data.categoryId).then((res) => {
            this.setData({
              categorySmall: res
            })
            cancelLoading();
          });
        });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})