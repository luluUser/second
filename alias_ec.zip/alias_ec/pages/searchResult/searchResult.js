// pages/searchResult/searchResult.js
// pages/classifyProduct/classifyProduct.js
import { searchProducts, showLoading, cancelLoading } from '../../utils/request.js';
let searchV = '';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    tinyNavIsShow: false,
    selectedIsok: true,//筛选条件
    brandSelectedIsok: '',//品牌点击动态添加
    brandHideShow: true,//品牌列表动态展示
    selectedList: [
      { dataOrder: 'desc', dataSorter: 'rank', content: '综合排序' },
      { dataOrder: 'desc', dataSorter: 'sales', content: '销量最多' },
      { dataOrder: 'desc', dataSorter: 'p_id', content: '最新上架' },
      { dataOrder: 'desc', dataSorter: 'price', content: '价格从高到低' },
      { dataOrder: 'asc', dataSorter: 'price', content: '价格从低到高' },
    ],
    defaultSelected: { dataOrder: 'desc', dataSorter: 'rank', content: '综合排序' },
    brandList: [],
    brandId: '',
    brandSureId: '',
    brandName: '',
    brandSureName: '',
    productList: [],//商品列表数据
    productAll: '',
    pages: 1,
    canloadMore: true,
    scrollTop: 0,

  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    searchV = options.searchVal;
    wx.setNavigationBarTitle({ title: searchV })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    let bindID = this.data.brandId;
    let bindName = this.data.bindName;
    showLoading();
    // console.log(typeId, page, defSelected)
    searchProducts(searchV, page, defSelected.dataSorter, defSelected.dataOrder, bindName, bindID).then((result) => {
      this.setData({
        productList: result.data.res.products,
        brandList: result.data.res.brandList,
        productAll: result.data.res.numFound
      });
      cancelLoading();
    });

  },
  getIniData() {
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    let bindID = this.data.brandId;
    let bindName = this.data.bindName;
    showLoading();
    // console.log(typeId, page, defSelected)
    searchProducts(searchV, page, defSelected.dataSorter, defSelected.dataOrder, bindName, bindID).then((result) => {
      this.setData({
        productList: result.data.res.products,
        productAll: result.data.res.numFound
      });
      cancelLoading();
    });
  },
  // 呼吸导航
  tinyNavHideShow: function () {
    this.setData({
      tinyNavIsShow: false
    });
  },
  // 呼吸导航。。。
  tinyNavHideShowprot: function () {
    this.setData({
      tinyNavIsShow: true
    });
  },
  // 跳转至搜索页面
  goToIndex: function () {
    wx.switchTab({
      url: "../index/index",
    })
  },
  // 跳转至搜索页面
  goToSearch: function () {
    wx.navigateTo({
      url: "../search/search",
    })
  },
  // 跳转至品牌商品页面
  goTobrandProducts: function (event) {
    let { brandid } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../brandProducts/brandProducts?brandId=${brandid}`,
    })
  },
  // 跳转至商品详情
  goToProductDetail: function (event) {
    let { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../productDetail/productDetail?id=${id}`,
    })
  },
  bindNone: function () { },
  // brand显示与隐藏
  branHideShow: function () {
    this.setData({
      brandHideShow: true
    });
  },
  brandShow: function () {
    this.setData({
      brandHideShow: false
    });
  },
  // 点击品牌-取消---隐藏
  cancelBtn: function () {
    this.setData({
      brandHideShow: true
    });
  },
  // 点击品牌-确认---隐藏与商品数据渲染
  sureBtn: function () {
    this.setData({
      brandHideShow: true,
      pages: 1,
      canloadMore: true,
      scrollTop: 0, //回到顶部
      brandId: this.data.brandSureId,
      brandName: this.data.brandSureName
    });
    this.getIniData();
  },
  // 点击全部品牌
  allBrand: function () {
    this.setData({
      brandHideShow: true,
      pages: 1,
      canloadMore: true,
      scrollTop: 0, //回到顶部
      brandId: '',
      bindName: '',
      brandSelectedIsok: ''
    });
    this.getIniData();
  },

  // 条件显示与隐藏
  hidShow: function () {
    if (this.data.selectedIsok) {
      this.setData({
        selectedIsok: false
      });
    } else {
      this.setData({
        selectedIsok: true
      });
    }
  },
  // 品牌点击
  toggleBrand: function (ev) {
    let { index, id, brandname } = ev.currentTarget.dataset;
    this.setData({
      brandSelectedIsok: index,
      brandSureId: id,
      brandSureName: brandname
    });
  },
  // 商品条件筛选
  selectedItems: function (event) {
    let { order, sorter, content } = event.currentTarget.dataset;
    console.log(order, sorter, content);
    this.setData({
      selectedIsok: true,
      pages: 1,
      canloadMore: true,
      scrollTop: 0, //回到顶部
      defaultSelected: { dataOrder: order, dataSorter: sorter, content }
    });
    this.getIniData();
  },

  // scroll-view滚动到底部,加载更多
  lower: function (e) {
    if (!this.data.canloadMore) {
      return;
    }
    this.setData({
      pages: this.data.pages + 1
    })
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    let bindID = this.data.brandId;
    let bindName = this.data.bindName;
    searchProducts(searchV, page, defSelected.dataSorter, defSelected.dataOrder, bindName, bindID).then((result) => {
      let tmp = this.data.productList.concat(result.data.res.products);
      if ( this.data.pages > (this.data.productAll)/10 ) {
        this.setData({
          canloadMore: false,
          productList: tmp
        });
      } else {
        this.setData({
          productList: tmp
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})