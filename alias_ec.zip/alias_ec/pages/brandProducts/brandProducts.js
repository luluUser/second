// pages/brandProducts/brandProducts.js
import { getBrandList, showLoading, cancelLoading } from '../../utils/request.js'
let brandId = '';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    tinyNavIsShow: false, //呼吸导航
    term1: true,
    term2: false,
    term3: false,
    term4: false,
    term4Selected1: false,
    term4Selected2: true,
    term4Selected12: false,
    canloadMore: true,
    collectIsOK: true,
    defaultSelected: { dataOrder: 'desc', dataSorter: 'rank', content: '综合排序' },
    productList: [],//商品列表数据
    productAll: '',
    pages: 1,
    brandImg: '',
    brandName: '',
    brandNum: 0,
  },
  // 呼吸导航
  tinyNavHideShow: function () {
    this.setData({
      tinyNavIsShow: false
    });
  },
  // 呼吸导航。。。
  tinyNavHideShowprot: function () {
    this.setData({
      tinyNavIsShow: true
    });
  },
  // 跳转至搜索页面
  goToIndex: function () {
    wx.switchTab({
      url: "../index/index",
    })
  },
  // 跳转至商品详情
  goToProductDetail: function (event) {
    let { id } = event.currentTarget.dataset;
    wx.navigateTo({
      url: `../productDetail/productDetail?id=${id}`,
    })
  },

  // 
  collectBtn: function(){
    if (this.data.collectIsOK) {
      this.setData({
        collectIsOK: false
      })
    } else {
      this.setData({
        collectIsOK: true
      })
    }
  },
  termSelect1: function(event) {
    this.setData({
      term1: true,
      term2: false,
      term3: false,
      term4: false,
      term4Selected1: false,
      term4Selected2: true,
      term4Selected12: false,
      defaultSelected: { dataOrder: 'desc', dataSorter: 'rank', content: '综合排序' },
    })
    this.getIniData();
  },
  termSelect2: function (event) {
    // let { brandid } = event.currentTarget.dataset;
    this.setData({
      term1: false,
      term2: true,
      term3: false,
      term4: false,
      term4Selected1: false,
      term4Selected2: true,
      term4Selected12: false,
      defaultSelected: { dataOrder: 'desc', dataSorter: 'sales', content: '销量最多' },
    })
    this.getIniData();
  },
  termSelect3: function (event) {
    // let { brandid } = event.currentTarget.dataset;
    this.setData({
      term1: false,
      term2: false,
      term3: true,
      term4: false,
      term4Selected1: false,
      term4Selected2: true,
      term4Selected12: false,
      defaultSelected: { dataOrder: 'desc', dataSorter: 'p_id', content: '最新上架' },
    })
    this.getIniData();
  },
  termSelect4: function (event) {
    // let { brandid } = event.currentTarget.dataset;
    if (this.data.term4Selected12) {
      this.setData({
        term1: false,
        term2: false,
        term3: false,
        term4: true,
        term4Selected1: false,
        term4Selected2: false,
        term4Selected12: false,
        defaultSelected: { dataOrder: 'asc', dataSorter: 'price', content: '价格从低到高' },
      })
      this.getIniData();
    } else {
      this.setData({
        term1: false,
        term2: false,
        term3: false,
        term4: true,
        term4Selected1: true,
        term4Selected2: true,
        term4Selected12: true,
        defaultSelected: { dataOrder: 'desc', dataSorter: 'price', content: '价格从高到低' },
      })
      this.getIniData();
    }
        
     
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    brandId = options.brandId;
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    showLoading();
    console.log(page, defSelected, brandId)
    getBrandList(page, defSelected.dataSorter, defSelected.dataOrder, brandId).then((result) => {
      this.setData({
        productList: result.products,
        brandImg: result.products[0].brandThumb,
        brandName: result.brandList[0].brandName,
        brandNum: result.brandList[0].count,
        productAll: result.numFound
      });
      wx.setNavigationBarTitle({ title: result.brandList[0].brandName })
      cancelLoading();
    });
  },
  getIniData() {
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    showLoading();
    console.log(page, defSelected, brandId)
    getBrandList(page, defSelected.dataSorter, defSelected.dataOrder, brandId ).then((result) => {
      this.setData({
        productList: result.products,
        productAll: result.numFound
      });
      cancelLoading();
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.canloadMore) {
      return;
    }
    this.setData({
      pages: this.data.pages + 1
    })
    let page = this.data.pages;
    let defSelected = this.data.defaultSelected;
    showLoading();
    console.log(page, defSelected, brandId);
    getBrandList(page, defSelected.dataSorter, defSelected.dataOrder, brandId).then((result) => {
      let tmp = this.data.productList.concat(result.products);
      if (this.data.pages > (this.data.productAll) / 10) {
        this.setData({
          canloadMore: false,
          productList: tmp
        });
      } else {
        this.setData({
          productList: tmp
        });
      }
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})