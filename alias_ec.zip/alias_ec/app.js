App({

  /**
   * 当小程序初始化完成时，会触发 onLaunch（全局只触发一次）
   */
  onLaunch: function () {
    wx.onNetworkStatusChange(function (res) {
      // console.log(res.isConnected)是否连接网络，true、false
      // console.log(res.networkType)连接类型
      if (!res.isConnected) {
        wx.showToast({
          title: '请链接网络',
          icon: 'none',
          duration: 5000
        })
      }
    })
    wx.getNetworkType({
      success: function (res) {
        // 返回网络类型, 有效值：
        // wifi/2g/3g/4g/unknown(Android下不常见的网络类型)/none(无网络)
        var networkType = res.networkType
        if (networkType == 'none') {
          wx.showToast({
            title: '请链接网络',
            icon: 'none',
            duration: 5000
          })
        }
      }
    })
  },

  /**
   * 当小程序启动，或从后台进入前台显示，会触发 onShow
   */
  onShow: function (options) {
   
  },

  /**
   * 当小程序从前台进入后台，会触发 onHide
   */
  onHide: function () {
    
  },

  /**
   * 当小程序发生脚本错误，或者 api 调用失败时，会触发 onError 并带上错误信息
   */
  onError: function (msg) {
    
  },

  // 全局值，在哪都可以用，通过this可以访问到
  globalreq: "https://m.baai.com/"
  
})