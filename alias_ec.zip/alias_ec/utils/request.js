const app = getApp();
let reqData = {};

reqData = {
  // 页面加载
  showLoading: function () {
    wx.showToast({
      title: '加载中',
      icon: 'loading'
    });
  },
  cancelLoading: function () {
    wx.hideToast();
  },



  // 首页数据
  getIndex: function () {
    return new Promise((resolve, reject)=>{
      wx.request({
        url: app.globalreq + 'index/new',
        data: '',
        header: {},
        method: 'GET',
        dataType: 'json',
        responseType: 'text',
        success: (res) => {
          console.log(res)
          let resdata = res.data;
          if (res.statusCode == 200) {
            resolve(res.data.data)
          }
        },
        fail: function (res) { },
        complete: function (res) { },
      })
    })
  },
  // 商品分类
  getcategory: function () {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + 'classify',
        data: '',
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res)
          let resdata = res.data;
          if (res.statusCode == 200) {
            resolve(resdata.data)
          }
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },
  // 商品分类--小类
  getSmallcategory: function (id) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + 'classify/' + id,
        data: '',
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          console.log(res)
          let resdata = res.data;
          if (res.statusCode == 200) {
            resolve(resdata.data)
          }
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },




  // 分类商品数据
  getCategoryProduct: function (typeId, page, order, sorter, types, brandId) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + 'type/' + typeId,
        data: {
          typeId, 
          page,
          order, 
          sorter, 
          'type': types, 
          brandId
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          console.log(res.data)
          let resdata = res.data;
          if (res.statusCode == 200) {
            resolve(resdata)
          }
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },


  // 搜索商品数据
  searchProducts: function (name, page, sort, order, brandName, brandId) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + 'forword/search',
        data: {
          name,
          page,
          sort,
          order,
          brandName,
          brandId
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          console.log(res)
          if (res.statusCode == 200) {
            resolve(res)
          }
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },



  // 商品详情数据
  getProductsDetail: function (productId) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + productId,
        data: { },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          console.log(res)
          resolve(res)
          
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },
  // 商品详--评论
  getProductsComment: function (productId) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + 'product/comment/' + productId,
        data: {},
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          // console.log(res)
          if (res.statusCode == 200) {
            resolve(res.data.data)
          }
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },



  // 品牌列表
  getBrandList: function ( page, sort, order, brandId) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: app.globalreq + 'forword/search',
        data: {
          'name': '*',
          page,
          sort,
          order,
          brandId
        },
        method: 'GET',
        dataType: 'json',
        success: (res) => {
          console.log(res.data.res)
          if (res.statusCode == 200) {
            resolve(res.data.res)
          }
        },
        fail: function (res) { console.log(res) },
        complete: function (res) { },
      })
    })
  },
};

module.exports = reqData;